package com.example.shop.model;

public enum PaymentStatus {
    PENDING,
    COMPLETED,
    REFUNDED,
    FAILED
}