package com.example.shop.model;

public abstract class Measurement {
    private String name;
    private String symbol;
}
