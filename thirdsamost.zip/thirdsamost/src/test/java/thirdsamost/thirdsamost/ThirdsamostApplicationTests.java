package thirdsamost.thirdsamost;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThirdsamostApplicationTests {

	@Test
	void contextLoads() {
	}

}
