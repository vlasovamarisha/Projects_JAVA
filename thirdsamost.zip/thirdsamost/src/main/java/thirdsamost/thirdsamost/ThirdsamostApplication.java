package thirdsamost.thirdsamost;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThirdsamostApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThirdsamostApplication.class, args);
	}

}
